package com.nafi.nafstory.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.liveData
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.nafi.nafstory.data.DataRepository
import com.nafi.nafstory.data.remote.model.home.ListStory
import com.nafi.nafstory.utils.PrefsManager
import kotlinx.coroutines.Job

class HomeViewModel constructor (private val dataRepository: DataRepository): ViewModel() {

    private lateinit var prefsManager: PrefsManager
    private var token: String?=null

    var quote: LiveData<PagingData<ListStory>>/*(PagingData.empty())*/= MutableLiveData()

    fun getStory(auth: String) {
        quote = dataRepository.getQuote(auth).cachedIn(viewModelScope)
    }




//    val quote: LiveData<PagingData<ListStory>> =
//        dataRepository.getQuote(prefsManager.token).cachedIn(viewModelScope)
//    private val listStory = MutableLiveData<NetworkResult<ResponseHome>>()
    private var job: Job? = null

//    fun fetchListStory(auth: String) {
//        job = viewModelScope.launch {
//            dataRepository.getStories(auth).collectLatest {
//                dataRepository.value = it
//            }
//        }
//    }

//    val responseListStory: LiveData<NetworkResult<ListStory>> = ListStory


    override fun onCleared() {
        super.onCleared()
        job?.cancel()
    }
}